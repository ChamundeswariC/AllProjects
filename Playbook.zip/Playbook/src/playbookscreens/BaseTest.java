package playbookscreens;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

public class BaseTest {

	public static WebDriver driver;
	
	@Parameters({"browser"})
	@BeforeSuite
	public void setUp(@Optional("chrome") String browser) throws InterruptedException {
        if ("firefox".equalsIgnoreCase(browser)) {
            FirefoxOptions options = new FirefoxOptions();


            driver = new FirefoxDriver(options);
        } else if ("edge".equalsIgnoreCase(browser)) {
            EdgeOptions options = new EdgeOptions();


            driver = new EdgeDriver(options);
        } else {
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--disable-notifications");

            driver = new ChromeDriver(options);
        }
        driver.manage().timeouts().implicitlyWait(Duration.ofMillis(10000));
        driver.manage().window().maximize();
        driver.get(TestInputDataPage.Url);
        Thread.sleep(4000);
        login();
    }

	@AfterSuite
    public void closeBrowser() throws InterruptedException {
		 try {
		        logout(); // Attempt to logout
		    } catch (Exception e) {
		        System.out.println("Exception occurred during logout: " + e.getMessage());
		    } finally {
		        if (driver != null) {
		            driver.quit(); // Close the browser, whether or not there was an exception
		        } else {
		            System.out.println("driver not found");
		        }
		    }
    }
  
    @BeforeMethod(alwaysRun = true)
    @Parameters("browser")
    public void beforeMethod(@Optional("chrome") String browser) {
        System.out.println("Test is starting with browser: " + browser);
    }


    @AfterMethod
    public void afterMethod(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            captureScreenshot(result.getName());
        }
    }

    private void captureScreenshot(String testName) {
        if (driver instanceof TakesScreenshot) {
            TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
            File screenshot = takesScreenshot.getScreenshotAs(OutputType.FILE);

            try {
                String screenshotsPath = "C:\\Users\\Spraxa\\eclipse-workspace\\Playbook\\Screenshots";
                File screenshotsDirectory = new File(screenshotsPath);


                if (!screenshotsDirectory.exists()) {
                    screenshotsDirectory.mkdir();
                }

                Path destinationPath = screenshotsDirectory.toPath().resolve(testName + ".png");
                Files.copy(screenshot.toPath(), destinationPath, StandardCopyOption.REPLACE_EXISTING);
                System.out.println("Screenshot saved at: " + destinationPath);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private void login() throws InterruptedException {
    	LoginPage loginPage = new LoginPage(driver);
        loginPage.enterUsername(TestInputDataPage.VALID_USERNAME);
        Thread.sleep(4000);
        loginPage.enterPassword(TestInputDataPage.VALID_PASSWORD);
        Thread.sleep(4000);
        loginPage.clickLoginButton();
    }
    private void logout() throws InterruptedException {
    	LoginPage loginPage=new LoginPage(driver);
    	 loginPage.clickProfileButton();
         Thread.sleep(4000);
         loginPage.clickLogoutButton();
    }
    public void takesscreenshot() throws IOException {
		LocalTime currenttime = LocalTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH_mm_ss"); // Use underscores instead of colons
		String time = currenttime.format(formatter);
		 File file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	        Path sourcePath = file.toPath();
	        Path targetPath = Paths.get("C:\\Users\\Spraxa\\eclipse-workspace\\Playbook\\Screenshots\\sorting" + time + ".jpg");

	        try {
	            Files.copy(sourcePath, targetPath);
	            System.out.println("Screenshot saved successfully.");
	        } catch (IOException e) {
	            e.printStackTrace(); 
	        }
	    }
  
    }

