package playbookscreens;


import org.testng.annotations.Test;

public class LoginPageTest extends BaseTest {
	
	@Test()
   
    public void TestDevPLaybookScreens() throws InterruptedException {
		LoginPage loginPage = new LoginPage(driver);
//        Thread.sleep(2000);
//        loginPage.enterUsername(LoginPageTestData.VALID_USERNAME);
//        Thread.sleep(4000);
//        loginPage.enterPassword(LoginPageTestData.VALID_PASSWORD);
//        Thread.sleep(4000);
//        loginPage.clickLoginButton();
      //  Assert.assertEquals(driver.getTitle(), "CoolR | Dashboard","Login Home page title not matched");
        Thread.sleep(2000);
         loginPage.OpenEachScreen();
//        loginPage.clickProfileButton();
//        Thread.sleep(4000);
//        loginPage.clickLogoutButton();



    }
}


