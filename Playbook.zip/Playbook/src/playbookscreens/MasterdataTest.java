package playbookscreens;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MasterdataTest extends BaseTest{

	@Test
	public void MasterDataTabs() throws InterruptedException, IOException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		MasterDataPage masterdata = new MasterDataPage(driver);
		Thread.sleep(5000);
		masterdata.clickMasterDataBtn();
		masterdata.ClickEachMasterdataTab();
		Thread.sleep(5000);
		masterdata.clickMasterDataBtn();
		Thread.sleep(2000);
		masterdata.EnterPagenumberAtJumptoPageField(TestInputDataPage.JumpToPageFieldPageNumber);
		Thread.sleep(3000);
		masterdata.RowsPerPageSelection(TestInputDataPage.NoOfRowsPagePage);
		Thread.sleep(3000);
		takesscreenshot();
		Thread.sleep(2000);
		masterdata.ClickFirstNameColumnFilterButton();
		masterdata.clickAscendingorder();
		Thread.sleep(3000);
		takesscreenshot();
		Thread.sleep(3000);
		masterdata.ClickFirstNameColumnFilterButton();
		Thread.sleep(3000);
		masterdata.clickDecendingorder();
		Thread.sleep(3000);
		takesscreenshot();
		Thread.sleep(3000);
	}
	

}
