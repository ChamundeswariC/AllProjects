package playbookscreens;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.google.common.io.Files;

public class OutletsPage {
	private final WebDriver driver;
	private By Outlets=By.xpath("//div[text()='Outlets']");
	private By Listview=By.xpath("//span[text()='Small']");
	private By Largeview=By.xpath("//span[text()='Large']");
	private By Mapview=By.xpath("//span[text()='Map']");
	private By OutletFirstcard=By.xpath("(//div[@class='outlet-image-container outlet-image-container-five'])[1]");
	private By outletOverviewOptions=By.xpath("//button//span[@class='MuiTab-wrapper']");
	private By closeoutletsoverviewtab=By.xpath("//div[contains(@id, 'max-width-dialog-title')]//*[name()='svg']");
	//private By closeoutletsoverviewtab=By.xpath("//*[@id='max-width-dialog-title']/h2/div/div[2]");
	private By fourthoutlet=By.xpath("(//div[@class='outlet-image-container outlet-image-container-five'])[4]");
	private By optionsbtn=By.xpath("//button//span[text()='Options']");
	private By clicksort=By.xpath("(//div[@id='panel1a-header'])[4]");
	private By clicksubsortbtn=By.xpath("(//div[@class='MuiFormControl-root'])[7]");
	private By beforesorting=By.xpath("//span[@class='MuiTypography-root MuiCardHeader-title MuiTypography-h5 MuiTypography-displayBlock']");//A-z
	private By selectdropdown=By.xpath("//ul//li[@role='option']");
	private By applysortingbtn=By.xpath("//button//span[text()='Apply']");
	private By outletsNames=By.xpath("//span[@class='MuiTypography-root MuiCardHeader-title MuiTypography-h5 MuiTypography-displayBlock']");






	public OutletsPage(WebDriver driver) {
		this.driver = driver;
	}
	public void clickOutletsScreen() {
		WebElement outletsBtn = driver.findElement(Outlets);
		outletsBtn.click();
	}
	public void clicklargeview() {
		WebElement Largeviewbtn=driver.findElement(Largeview);
		Largeviewbtn.click();
		System.out.println(Largeviewbtn.getText()+" View tab Clicked Successfully");

	}
	public void clicklistview() {
		WebElement Listviewbtn=driver.findElement(Listview);
		Listviewbtn.click();
		System.out.println(Listviewbtn.getText()+" View tab Clicked Successfully");
	}
	public void clickmapview() {
		WebElement mapviewbtn=driver.findElement(Mapview);
		mapviewbtn.click();
		System.out.println(mapviewbtn.getText()+" View tab Clicked Successfully");
	}
	public void clickoutletfirstcard() {
		WebElement firstoutletcard=driver.findElement(OutletFirstcard);
		firstoutletcard.click();
		System.out.println("First Outlet Opened Successfully");
	}
	public void clickOutletOverviewOptions() throws InterruptedException {
		List<WebElement>Outletinformationoptions=driver.findElements(outletOverviewOptions);
		for(WebElement clickeachtab:Outletinformationoptions) {
			clickeachtab.click();
			System.out.println(clickeachtab.getText()+" Tab clicked in Outlet Overview");
			Thread.sleep(2000);
		}
	}
	public void closeoutletsoverviewtab() throws InterruptedException {
		WebElement closeoutletoverviewtab=driver.findElement(closeoutletsoverviewtab);
		Actions actions = new Actions(driver);
		actions.moveToElement(closeoutletoverviewtab).build().perform();
		actions.click().build().perform();
		Thread.sleep(3000);
		actions.sendKeys(Keys.PAGE_UP).perform();
		Thread.sleep(2000);
		//driver.navigate().refresh();

	}
	public void ClickFourthOutlet() {
		WebElement fourthelement=driver.findElement(fourthoutlet);
		fourthelement.click();
		System.out.println("Fourth Outlet Opened Successfully");
	}
	public void ApplyingSorting() throws InterruptedException {
		WebElement optionsbtnn=driver.findElement(optionsbtn);
		optionsbtnn.click();
		Thread.sleep(2000);
		WebElement sortbtn=driver.findElement(clicksort);
		sortbtn.click();
		Thread.sleep(2000);
		WebElement subsortbtn=driver.findElement(clicksubsortbtn);
		subsortbtn.click();
	}

	public void sortingappliedwith(String sortingOption) {
	    List<WebElement> sort = driver.findElements(selectdropdown);
	    
	    for (WebElement sortoption : sort) {
	        if (sortoption.getText().equalsIgnoreCase(sortingOption)) {
	            sortoption.click();
	            System.out.println(sortoption.getText() + " Filter applied Successfully");
	        }
	    }
	}
	public void LastImageApprovedSortingValidation() {
		
		List<WebElement> outlets = driver.findElements(By.xpath("//span[@class='MuiTypography-root MuiTypography-caption']"));
		LocalDate mostRecentDate = null;
		for (WebElement dateElement : outlets) {
			String extractedDate = extractDate(dateElement.getText());
			if (extractedDate != null) {
				LocalDate currentDate = LocalDate.parse(extractedDate, DateTimeFormatter.ofPattern("dd.MM.yyyy"));
				if (mostRecentDate == null || currentDate.isAfter(mostRecentDate)) {
					mostRecentDate = currentDate;
				}
			}
		}
		if (mostRecentDate != null) {
			System.out.println("Last Image Approved Date: " + mostRecentDate.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
		} else {
			System.out.println("No valid date found.");
		}
	}
	private static String extractDate(String inputString) {
		String patternString = "\\d{2}\\.\\d{2}\\.\\d{4}";
		Matcher matcher = Pattern.compile(patternString).matcher(inputString);
		return matcher.find() ? matcher.group() : null;

	}

	public void clickapplybtn(){
		WebElement applybtn=driver.findElement(applysortingbtn);
		applybtn.click();
	}
	public void AtoZvalidation() {
		
		List<WebElement> outlets = driver.findElements(outletsNames);
		List<String> textBeforeSorting = new ArrayList<>();
		for (WebElement outlet : outlets) {
			textBeforeSorting.add(outlet.getText());
		}
		Collections.sort(textBeforeSorting);
		List<WebElement> outletsAfterSorting = driver.findElements(outletsNames);
		List<String> textAfterSorting = new ArrayList<>();
		for (WebElement outlet : outletsAfterSorting) {
			textAfterSorting.add(outlet.getText());
		}
		System.out.println("After Sorting A-Z outlets");
		for (int i = 0; i < Math.min(3, textAfterSorting.size()); i++) {
			System.out.println("outlet name "+textAfterSorting.get(i));
		}
		if (textBeforeSorting.equals(textAfterSorting)) {
			System.out.println("Validation: Text content matches before and after sorting.");
		} else {
			System.out.println("Validation failed: Text content does not match after sorting.");
		}	    

	}
public void ZtoAvalidation() {
	 List<WebElement> elements = driver.findElements(outletsNames);
	 System.out.println("First 3 outlets after Z-A sorting ");
	 for (int i = 0; i < Math.min(3, elements.size()); i++) {
         System.out.println("Outlet Names " + (i + 1) + ": " + elements.get(i).getText());
     }
     List<String> actualOrder = new ArrayList<>();
     for (WebElement element : elements) {
         actualOrder.add(element.getText());
     }

     // Use a custom comparator to sort in descending order (Z-A)
     actualOrder.sort(Comparator.reverseOrder());

     // Now you can validate the order
     List<String> expectedOrder = new ArrayList<>(actualOrder);
     Collections.sort(expectedOrder, Collections.reverseOrder());

     // Assert that the elements are in descending order
     Assert.assertEquals(expectedOrder, actualOrder,"not matched filter failed");
    }
}
