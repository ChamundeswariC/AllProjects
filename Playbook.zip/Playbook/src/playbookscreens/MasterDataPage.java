package playbookscreens;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MasterDataPage {
	private final WebDriver driver ;


	private By MasterdataBtn=By.xpath("//span[text()='Master Data']");
	private By MasterdataTabs = By.xpath("//span[@class='MuiTab-wrapper']");
	private By JumptoPageField = By.xpath("//input[@id=':r5:']");
	private By JumptoPageFieldGoBtn=By.xpath("//button[text()='Go']");
	private By RowsperPageBtn=By.xpath("//div[@id=':r6:']");
	private By RowsperPageDropDown=By.xpath("//ul//li[@role='option']");
	private By dashboardall=By.xpath("//ul//li[@class='MuiListItem-root app-sidebar-item']");
	private By FirstNameColumnFilterBtn=By.xpath("//div[@class='MuiDataGrid-columnHeaderTitleContainer']/following-sibling::div");
	private By SortingOrderBtn=By.xpath("(//button[@title='Sort'])[1]");
	private By SortingOrderAscending=By.xpath("//span[text()='Sort by ASC']");
	private By SortingOrderdescending=By.xpath("//ul//li[@data-value='desc']");

	public MasterDataPage(WebDriver driver) {
		this.driver=driver;
	}

	public void clickMasterDataBtn() {
		WebElement loginBtn = driver.findElement(MasterdataBtn);
		loginBtn.click();	
	}
	public void ClickEachMasterdataTab() throws InterruptedException {
		List<WebElement>AllTabs=driver.findElements(MasterdataTabs);

		for(WebElement ele : AllTabs) {
			ele.click();
			Thread.sleep(3000);
		}
		driver.navigate().refresh();
	}
	public void EnterPagenumberAtJumptoPageField(int JumpToPageFieldPageNumber) throws InterruptedException {
		WebElement Jumptopagefield = driver.findElement(JumptoPageField);
		Thread.sleep(3000);
		Actions act=new Actions(driver);
		act.moveToElement(Jumptopagefield).click().build().perform();
		Jumptopagefield.sendKeys(Keys.CONTROL+"a");
		Thread.sleep(5000);
		act.sendKeys(Keys.BACK_SPACE).perform();
		Thread.sleep(3000);
		act.sendKeys(String.valueOf(JumpToPageFieldPageNumber)).build().perform();
		Thread.sleep(3000);
		driver.findElement(JumptoPageFieldGoBtn).click();
		System.out.println("Page successfully navigated to "+JumpToPageFieldPageNumber + " page");


	}
	public void RowsPerPageSelection(int NoOfRowsPerPage) throws InterruptedException {
		WebElement RowsPerPageBtn = driver.findElement(RowsperPageBtn);
		RowsPerPageBtn.click();
		Thread.sleep(3000);

		List<WebElement> Drpdowns = driver.findElements(RowsperPageDropDown);

		for (WebElement dropdownOption : Drpdowns) {
			int optionValue = Integer.parseInt(dropdownOption.getText().trim());

			if (optionValue == NoOfRowsPerPage) {
				dropdownOption.click();
				System.out.println("No of rows per page changed to " + optionValue +" Successfully");

			}
		}
		Thread.sleep(3000);
		Actions act = new Actions(driver);
		act.sendKeys(Keys.PAGE_DOWN).perform();

	}
	public void ClickFirstNameColumnFilterButton() throws InterruptedException {
		WebElement sort=driver.findElement(SortingOrderBtn);
		WebElement filter=driver.findElement(FirstNameColumnFilterBtn);
		Actions act=new Actions(driver);
		act.moveToElement(sort).build().perform();
		act.moveToElement(filter).click().perform();
		Thread.sleep(3000);
	}
	public void clickAscendingorder() throws InterruptedException {
		WebElement Asc=driver.findElement(SortingOrderAscending);
		Actions act=new Actions(driver);
		Thread.sleep(3000);
		Asc.click();
		System.out.println(Asc.getText()+" Ascending Order Filter Applied Successfully");
		Thread.sleep(3000);

	}
	public void clickDecendingorder() throws InterruptedException {
		WebElement Desc=driver.findElement(SortingOrderdescending);
		Actions act=new Actions(driver);
		Thread.sleep(3000);
		Desc.click();
		System.out.println(Desc.getText()+" Descending Order Filter Applied Successfully");
		Thread.sleep(3000);

	}
	public void clickapplysortingorder() throws InterruptedException {
		WebElement Asc=driver.findElement(SortingOrderBtn);
		Actions act = new Actions(driver);
		act.moveToElement(Asc).click().build().perform();
		Thread.sleep(3000);
		act.sendKeys(Keys.PAGE_DOWN).build().perform();
		System.out.println("Sorting order SuccessFully Applied "+Asc.getText());

	}





}




