package playbookscreens;

import java.io.IOException;
import java.time.Duration;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class OutletsTest extends BaseTest {

	@Test
   
	public void outletsScreens() throws InterruptedException, IOException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//LoginPage loginPage = new LoginPage(driver);
		SoftAssert softAssert = new SoftAssert();
		TestInputDataPage testinputdata=new TestInputDataPage();
		Thread.sleep(4000);
		OutletsPage outletpage=new OutletsPage(driver);
		outletpage.clickOutletsScreen();
		Thread.sleep(3000);
		outletpage.clicklargeview();
		Thread.sleep(3000);
		outletpage.clickmapview();
		Thread.sleep(8000);
		outletpage.clicklistview();
		Thread.sleep(3000);
		outletpage.clickoutletfirstcard();
		outletpage.clickOutletOverviewOptions();
		outletpage.closeoutletsoverviewtab();
		Thread.sleep(3000);
		outletpage.ClickFourthOutlet();
		Thread.sleep(3000);
		outletpage.clickOutletOverviewOptions();
		Thread.sleep(3000);
		outletpage.closeoutletsoverviewtab();
		Thread.sleep(3000);
		outletpage.ApplyingSorting();
		Thread.sleep(3000);
		outletpage.sortingappliedwith(testinputdata.SORTOPTIONLASTIMAGEAPPROVEDDATE);
		Thread.sleep(3000);
		outletpage.clickapplybtn();
		Thread.sleep(3000);
		outletpage.LastImageApprovedSortingValidation();
		Thread.sleep(3000);
		takesscreenshot();
		Thread.sleep(3000);
		outletpage.ApplyingSorting();
		Thread.sleep(3000);
		outletpage.sortingappliedwith(testinputdata.SORTOPTIONAtoZ);;
		Thread.sleep(3000);
		outletpage.clickapplybtn();
		Thread.sleep(3000);
		outletpage.AtoZvalidation();
		Thread.sleep(3000);
		takesscreenshot();
		Thread.sleep(3000);
		outletpage.ApplyingSorting();
		Thread.sleep(3000);
		outletpage.sortingappliedwith(testinputdata.SORTOPTIONZtoA);
		Thread.sleep(3000);
		outletpage.clickapplybtn();
		Thread.sleep(3000);
		outletpage.ZtoAvalidation();
		Thread.sleep(3000);
		takesscreenshot();
		Thread.sleep(3000);
		softAssert.assertAll();
	}
}