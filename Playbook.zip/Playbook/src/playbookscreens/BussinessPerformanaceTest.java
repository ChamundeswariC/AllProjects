package playbookscreens;

import org.testng.annotations.Test;

public class BussinessPerformanaceTest extends BaseTest {
	@Test
	public void Bussinessperformance() throws InterruptedException {
		BusinessPerformancePage bussinessperformance=new BusinessPerformancePage(driver);
		Thread.sleep(3000);
		bussinessperformance.ClickBussinessPerformanaceTabs();
	}

}
