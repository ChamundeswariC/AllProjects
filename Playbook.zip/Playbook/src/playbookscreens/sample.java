package playbookscreens;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
public class sample {

	public static void main(String[] args) throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-notifications");
		WebDriver driver = new ChromeDriver(options);

      driver.manage().window().maximize();
      driver.get("https://playbook.coolrgroup.com/");
      Thread.sleep(3000);
      driver.findElement(By.id("standard-basic")).sendKeys("test.script@coolrgroup.com");
      driver.findElement(By.xpath("(//input[@id='standard-basic'])[2]")).sendKeys("Admin@12345");
      driver.findElement(By.xpath("//span[text()='LOGIN']")).click();
      Thread.sleep(3000);


      List<WebElement> allElements = driver.findElements(By.xpath("//ul//li[@class='MuiListItem-root app-sidebar-item']"));

      int maxWaitTimeInSeconds = 3;
      for (int i = 0; i < allElements.size(); i++) {
    	    long startTime = System.currentTimeMillis();

    	    if (i != 2) {
    	        WebElement ele = allElements.get(i);
    	        ele.click();

    	        try {
    	            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(maxWaitTimeInSeconds));
    	            wait.until((ExpectedCondition<Boolean>) webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    	            long endTime = System.currentTimeMillis();
    	            System.out.println("Text: " + ele.getText());
    	            System.out.println("Page Url: " + driver.getCurrentUrl());
    	            long duration = endTime - startTime;
    	            System.out.println("Loaded within " + duration + " milliseconds");
    	            if (duration > maxWaitTimeInSeconds * 1000) {
    	                System.out.println("Took more than " + maxWaitTimeInSeconds + " seconds to load\n");
    	            } else {
    	                System.out.println("Loaded within expected 3 seconds\n");
    	            }
    	        } catch (Exception e) {
    	            System.out.println("Text: " + ele.getText());
    	            System.out.println("Page did not load within " + maxWaitTimeInSeconds + " seconds\n");
    	        }
    	    }
    	    Thread.sleep(3000);
    	}
      driver.quit();
	}


	}

