package playbookscreens;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class BusinessPerformancePage {
	private final WebDriver driver;
	private By Bussiness=By.xpath("//span[contains(text(),'Business Performance')]");
	private By merchendising=By.xpath("xpath=//div[@id='root']/div[2]/div[2]/div[2]/div/div/div/div/div[2]/div/div/div/div[3]/div/i");
	private By portfolio =By.xpath("xpath=//div[@id='root']/div[2]/div[2]/div[2]/div/div/div/div/div[2]/div/div[2]/div/div[3]/div");
	private By salesshopper=By.xpath("//div[text()='Sales & Shopper']");
	private By optionbtn=By.xpath("//span[normalize-space()='Options']");
	private By market=By.xpath("(//div[@class='MuiGrid-root dis-grid mb-2 MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 MuiGrid-grid-md-12 MuiGrid-grid-lg-12'])[1]");
	private By marketDrpdown=By.xpath("//ul/li[@role='option']");
	private By dateDrpDown=By.xpath("(//div[@class='MuiGrid-root dis-grid mb-2 MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 MuiGrid-grid-md-12 MuiGrid-grid-lg-12'])[5]");
	private By Applybtn=By.xpath("//span[text()='Apply']");
	private By subtabsBussiness=By.xpath("//div[@class='MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 MuiCard-root cursor_pointer ifh-status-card css-s18byi']");
	
	
	public BusinessPerformancePage(WebDriver driver) {
		this.driver = driver;
	}
public void ClickBussinessPerformanaceTabs() throws InterruptedException {
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	WebElement Bussinessbtn=driver.findElement(Bussiness);
	Actions act=new Actions(driver);
	Bussinessbtn.click();
	Thread.sleep(3000);

	WebElement Clickmerchendizing=driver.findElement(merchendising);
	act.moveToElement(Clickmerchendizing).build().perform();
	act.click().build().perform();
	Thread.sleep(3000);
	
	System.out.println(Clickmerchendizing.getText()+" Successfully Clicked");
	
	driver.findElement(By.xpath("//label[@class='MuiButtonBase-root MuiIconButton-root back-button']")).click();
	Thread.sleep(3000);
	WebElement ClickPortfolio=driver.findElement(portfolio);
	act.moveToElement(Clickmerchendizing).build().perform();
	act.click().build().perform();
	System.out.println(ClickPortfolio.getText()+" Successfully Clicked");
	Thread.sleep(3000);
	driver.findElement(By.xpath("//label[@class='MuiButtonBase-root MuiIconButton-root back-button']")).click();
	
	Thread.sleep(3000);
	WebElement clickSalesShopperbtn=driver.findElement(salesshopper);
	act.moveToElement(Clickmerchendizing).build().perform();
	act.click().build().perform();
		System.out.println(clickSalesShopperbtn.getText()+" Successfully Clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//label[@class='MuiButtonBase-root MuiIconButton-root back-button']")).click();
		
		Thread.sleep(3000);
	}
}

