package playbookscreens;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class ValidateSortingOrder extends BaseTest {
	@Test
public void validate() throws InterruptedException {
		 driver.manage().timeouts().implicitlyWait(Duration.ofMillis(10000));

	        driver.findElement(By.xpath("//div[text()='Outlets']")).click();
	        List<WebElement> outlets = driver.findElements(By.xpath("//span[@class='MuiTypography-root MuiCardHeader-title MuiTypography-h5 MuiTypography-displayBlock']"));
	        List<String> textBeforeSorting = new ArrayList<>();
	        for (WebElement outlet : outlets) {
	            textBeforeSorting.add(outlet.getText());
	        }
	        Collections.sort(textBeforeSorting);
	        List<WebElement> outletsAfterSorting = driver.findElements(By.xpath("//span[@class='MuiTypography-root MuiCardHeader-title MuiTypography-h5 MuiTypography-displayBlock']"));
	        List<String> textAfterSorting = new ArrayList<>();
	        for (WebElement outlet : outletsAfterSorting) {
	            textAfterSorting.add(outlet.getText());
	        }
	        if (textBeforeSorting.equals(textAfterSorting)) {
	            System.out.println("Validation: Text content matches before and after sorting.");
	        } else {
	            System.out.println("Validation failed: Text content does not match after sorting.");
	        }	    
}

	}