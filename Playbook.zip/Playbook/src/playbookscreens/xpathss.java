package playbookscreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class xpathss {

	public static void main(String[] args) throws Throwable {

		// System.setProperty("webdriver.chrome.driver",
		// "C:\\Users\\91988\\Downloads\\chromedriver_win32\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
		driver.get("https://www.google.com/");
		Thread.sleep(5000);
		// absolute xpath
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input")).sendKeys("Hello");
		//div[@class='_1YokD2 _3Mn1Gg']//div[2]//div[1]//div[1]//div[1]//a[1]//div[1]//div[2]//div[1]//span[1]//label[1]//div[1]
		Thread.sleep(5000);

		// relative xpath
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys("Hello");
		driver.findElement(By.xpath("//*[@name='q']")).sendKeys("Hello");

		// using or

		driver.findElement(By.xpath("//input[@name='q' or @type='text']")).sendKeys("Hello");

		// using and
		driver.findElement(By.xpath("//input[@name='q' and @type='text']")).sendKeys("Hello");

		// using contains
		driver.findElement(By.xpath("//input[contains(@type,'text')]")).sendKeys("Hello");

		// using starts-with
		driver.findElement(By.xpath("//input[starts-with(@type,'tex')]")).sendKeys("Hello");

		// using text
		driver.findElement(By.xpath("//a[text()='తెలుగు']")).click();

		// using chained xpath ,this is used parent element to child element
		driver.findElement(By.xpath("//div[@id=\'SIvCob\']//a[3]")).click();// this is created with index number
		// driver.findElement(By.xpath("//div[@id=\"SIvCob\"]//a[@id='telugu']")).click();//
		// and this is used with attribute and attribute value

		driver.findElement(By.xpath("//*[@id='menu-item-3173']/a/span"));
		driver.findElement(By.xpath("/html/body/div[1]/header/div[1]/div/div/div/div/div/div/div/div[2]/div[1]/nav/div/ul/li[2]/a/span"));

		// html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input
		// html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input

		// *[@id="rso"]/div[1]/div/div/div[1]/div/div/div[1]/div/a/h3
		// html/body/div[7]/div/div[11]/div/div[2]/div[2]/div/div/div[1]/div/div/div[1]/div/div/div[1]/div/a/h3

		// PRECEDING XPATH= IT MEANS BASED ON ONE WEB ELEMENT WE CAN FOUND PREVIOUS ELEMENT

		// EXAMPLE = //input[@id='login']/preceding-sibling::button

		// following xpath= IT MEANS BASED ON ONE WEB ELEMENT WE CAN FOUND next ELEMENT

		// example = //input[@id='login']/following-sibling::button

	}

}



