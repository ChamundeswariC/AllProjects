package playbookscreens;

public class TestInputDataPage {

    // Valid user credentials for Live
	public static final String Url="https://playbook.coolrgroup.com/";
    public static final String VALID_USERNAME = "test.script@coolrgroup.com";
    public static final String VALID_PASSWORD = "Admin@12345";
 //MasterData   
    public static final int JumpToPageFieldPageNumber=2;
    public static final int NoOfRowsPagePage=5;

    // Valid user credentials for Dev Playbook
//    public static final String Url="https://playbook-dev.coolrgroup.com/";
//    public static final String VALID_USERNAME = "prasanna.kumar@spraxa.com";
//    public static final String VALID_PASSWORD = "Prasanna@2023";
    
 //outlets sorting
    public static final String SORTOPTIONLASTIMAGEAPPROVEDDATE = "Last Image Approved Date";
    public static final String SORTOPTIONZtoA = "Z-A";
    public static final String SORTOPTIONAtoZ = "A-Z";
    
    
}


