package practicalinterview;

public class TestInputdata  {
	String Url="https://oilman-website.apps.openxcell.dev/login/";
	String validemail="viren@openxcell.com";
	String validPasswd="admin@1234";
	String invalidemail="viren@openxcel";
	String inavalidpasswd="admin@12";
	String Companyname="prasanna";
	String SearchNameInput="prasanna";

}
