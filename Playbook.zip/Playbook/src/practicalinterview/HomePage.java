package practicalinterview;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class HomePage extends Locatorshomepage {

	private WebDriver driver;
	private Actions actions;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		this.actions = new Actions(driver);
	}

	public void clickAssetsMenuOption() throws InterruptedException {
		List<WebElement> menuOptions = driver.findElements(LeftDashboardAllElements);
		for (WebElement menuOption : menuOptions) {
			String elementText = menuOption.getText();
			if (elementText.equals("Assets")) {
				actions.moveToElement(menuOption).click().build().perform();
				break;
			}
			Thread.sleep(5000);
		}
	}

	public void clickCompanyMenuOption() throws InterruptedException {
		driver.findElement(ClickOnCompany).click();
		Thread.sleep(3000);
	}

	public void Addcompanyclick() throws InterruptedException {
		driver.findElement(ClickPlusSymbol).click();
		Thread.sleep(3000);
	}

	public void setCompanyname(String text) throws InterruptedException {
		WebElement send = driver.findElement(GiveCompanynametoTextbar);
		actions.moveToElement(send).click().sendKeys(text).build().perform();
		Thread.sleep(3000);
	}

	public void confirmcompanyname() throws InterruptedException {
		LocalTime currenttime=LocalTime.now();
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("HH:mm");
		String time=currenttime.format(formatter);
		driver.findElement(ConfirmCompanyName).click();
		Thread.sleep(1000);
		String successmessage=driver.findElement(ReadCompanyAddedSuccessMeassage).getText();
		System.out.println(successmessage);
		Assert.assertEquals(successmessage, successmessage,"success message not matched");
		Thread.sleep(6000);
	}

	public void GiveCompanyNametoSearchbar(String text) throws InterruptedException {
		WebElement se = driver.findElement(SearchCompanyNameInTextbar);
		actions.moveToElement(se).click().build().perform();
		actions.moveToElement(se).click().build().perform();
		actions.moveToElement(se).sendKeys(text).build().perform();
		Thread.sleep(5000);
	}

	public void ClickOncompanyNameforEdit() throws InterruptedException {
		driver.findElement(EditVisibleCompanyName).click();
		Thread.sleep(3000);
	}
	public void SelectEdit() throws InterruptedException {
		driver.findElement(SelectEdit).click();
		Thread.sleep(5000);

	}

	public void GivingNewName(String text) throws InterruptedException {
		Thread.sleep(3000);

		WebElement se = driver.findElement(RemoveOldnameGiveNewname);
		se.click();
		se.sendKeys(Keys.chord(Keys.CONTROL,"a"));
		Thread.sleep(5000);
		se.sendKeys(Keys.DELETE);
		actions.moveToElement(se).click().build().perform();
		Thread.sleep(3000);
		actions.moveToElement(se).sendKeys(text).build().perform();
	}

	public void ConfirmCompanyNameAndSubmit() throws InterruptedException {
		driver.findElement(confirmCompanyNameAfterEdit).click();
		Thread.sleep(1000);
		WebElement update=driver.findElement(ReadEditedCompanySuccessfulluAddedNotification);
		System.out.println(update.getText());
		driver.navigate().refresh();
		Thread.sleep(5000);

	}
	public String Time() {

		LocalTime currenttime=LocalTime.now();
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("HH:mm:ss");
		String time=currenttime.format(formatter);
		return time;
	}

	public void ClickonDeleteCompanyName() {
		WebElement del=driver.findElement(ClickOnDeleteCompanynameOption);
		actions.moveToElement(del).click().build().perform();

	}

	public void ClickonDeleteoptionAndConfirm() throws InterruptedException {
		Thread.sleep(3000);
		WebElement compp=driver.findElement(SelectDeleteOption);
		actions.moveToElement(compp).click().build().perform();
		Thread.sleep(3000);
		WebElement delbutton=driver.findElement(DeleteButtonClick);
		actions.moveToElement(delbutton).click().build().perform();
		Thread.sleep(5000);
		WebElement delconfirmbutton=driver.findElement(confirmDeleteButton);
		actions.moveToElement(delconfirmbutton).click().build().perform();
		Thread.sleep(1000);
		WebElement delmessage=driver.findElement(ReadDeletedNotification);
		System.out.println(delmessage.getText());
	}

	public void printSuccessMessage() {
		System.out.println("Test Passed Success");

	}
}
