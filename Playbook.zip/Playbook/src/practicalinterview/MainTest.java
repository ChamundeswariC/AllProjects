package practicalinterview;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

public class MainTest {
	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = new HomePage(driver);
		SoftAssert softAssert = new SoftAssert();
		TestInputdata testdata=new TestInputdata();
//login with invalid credentials
		loginPage.openLoginPage(testdata.Url);
		System.out.println("Try to Login with invalid credentials");
		loginPage.maximizeWindow();
		loginPage.login(testdata.invalidemail, testdata.inavalidpasswd);

//Login with valid credenetials
		System.out.println("Login with Valid Credentials");
		loginPage.openLoginPage(testdata.Url);
		loginPage.maximizeWindow();
		loginPage.login(testdata.validemail, testdata.validPasswd);

		homePage.clickAssetsMenuOption();

		homePage.clickAssetsMenuOption();

		homePage.clickCompanyMenuOption();

		homePage.Addcompanyclick();

		homePage.setCompanyname(testdata.Companyname+homePage.Time());
		homePage.confirmcompanyname();

		homePage.GiveCompanyNametoSearchbar(testdata.SearchNameInput);

		homePage.ClickOncompanyNameforEdit();

		homePage.SelectEdit();

		homePage.GivingNewName("prasanna"+homePage.Time());

		homePage.ConfirmCompanyNameAndSubmit();

		homePage.GiveCompanyNametoSearchbar(testdata.SearchNameInput);

		homePage.ClickonDeleteCompanyName();

		homePage.ClickonDeleteoptionAndConfirm();

		homePage.printSuccessMessage();
		driver.quit();
		softAssert.assertAll();
	}

}
