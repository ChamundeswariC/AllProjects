package practicalinterview;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class LoginPage {

	private WebDriver driver;
	public void LaunchBrowser() {
		WebDriver driver=new ChromeDriver();
	}

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}
	//Login Function Elements
	By useremail=By.id(":R2htalaf6:");
	By userpassword=By.id("auth-login-v2-password");
	By clickloginbutton=By.xpath("//button[text()='Sign in']");
	By ReaderrorMessage=By.xpath("//div[@class='go3958317564']");

	public void openLoginPage(String url) {
		driver.get(url);
	}

	public void maximizeWindow() {
		driver.manage().window().maximize();
	}

	public void login(String username, String password) throws InterruptedException {
		SoftAssert softAssert = new SoftAssert();
		driver.findElement(useremail).sendKeys(username);
		driver.findElement(userpassword).sendKeys(password);
		driver.findElement(clickloginbutton).click();
		Thread.sleep(10000);

		try {
			WebElement errormessage=driver.findElement(ReaderrorMessage);
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofMillis(10000)) ;
			WebElement visibleElement=wait.until(ExpectedConditions.visibilityOf(errormessage));
			String error=errormessage.getText();
			System.out.println("Error Message Displayed "+error);
			softAssert.assertTrue(visibleElement.isDisplayed(), "Error message not displayed for invalid login");

		}catch(Exception e){
			System.out.println("login successfull");
			String title=driver.getTitle();
			System.out.println(title+" home page title Displayed login successfull");
			Assert.assertEquals(title,"oilman","welcome message not displayed");

		}
	}
}





