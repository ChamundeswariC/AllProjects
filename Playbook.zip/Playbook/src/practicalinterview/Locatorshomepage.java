package practicalinterview;

import org.openqa.selenium.By;

public class Locatorshomepage {

	//HomePage Elements
	By LeftDashboardAllElements = By.xpath("(//p[@class='MuiTypography-root MuiTypography-body1 MuiTypography-noWrap css-1u6z5b7'])");
	By ClickOnCompany = By.xpath("//p[text()='Company']");
	By ClickPlusSymbol = By.xpath("(//div[@class='MuiGrid-root MuiGrid-item css-1wxaqej'])[4]");
	By GiveCompanynametoTextbar = By.xpath("(//div[@class='MuiInputBase-root MuiFilledInput-root MuiFilledInput-underline MuiInputBase-colorPrimary MuiInputBase-fullWidth MuiInputBase-formControl MuiInputBase-sizeSmall css-jg2g9h'])[1]");
	By ConfirmCompanyName = By.xpath("(//button[@type='submit'])[1]");
	By ReadCompanyAddedSuccessMeassage = By.xpath("//div[@class='go3958317564']");
	By SearchCompanyNameInTextbar = By.xpath("//div//input[@placeholder='Search']");
	By EditVisibleCompanyName = By.xpath("//button[@class='MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeSmall css-mguc8w']");
	By SelectEdit = By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li[1]");
	By RemoveOldnameGiveNewname = By.id(":r17:");
	By confirmCompanyNameAfterEdit = By.xpath("(//div[@class='MuiBox-root css-70qvj9']//button)[3]");
	By ReadEditedCompanySuccessfulluAddedNotification=By.xpath("//div[text()='We have successfully updated the company.']");
	By ClickOnDeleteCompanynameOption=By.xpath("(//button[@type='button'])[4]");
	By SelectDeleteOption=By.xpath("(//ul[@role='menu']//li[2])[1]");
	By DeleteButtonClick=By.xpath("(//li[text()='Delete'])[1]");
	By confirmDeleteButton=By.xpath("//button[text()='Yes']");
	By ReadDeletedNotification=By.xpath("//div[text()='We have successfully deleted the company.']");
}
